// Twisted Star Vase. Open in OpenSCAD, then Window > Customizer to drag the sliders live.
// Press F5 to preview, F6 to render, then File > Export > STL.

points       = 7;    // [3:1:12]
outer_radius = 22;   // [10:1:30]
inner_radius = 15;   // [5:1:28]
height       = 70;   // [20:5:120]
twist        = 120;  // [0:10:360]
flare        = 1.25; // [0.6:0.05:1.8]
wall         = 2;    // [1.2:0.2:4]
floor_thick  = 2.5;  // [1:0.5:5]

module star(n, r1, r2) {
    polygon([for (i = [0 : 2*n - 1])
        let(r = (i % 2 == 0) ? r1 : r2, a = 180 * i / n)
        [r * cos(a), r * sin(a)]]);
}

module body(grow) {
    linear_extrude(height = height, twist = twist, scale = flare, slices = 80)
        offset(r = 2 + grow) star(points, outer_radius, inner_radius);
}

difference() {
    body(0);
    translate([0, 0, floor_thick]) body(-wall);
}
