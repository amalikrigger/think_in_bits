// Name Keychain. Change the words, size and font in the Customizer (Window > Customizer).

name        = "MR KRIGGER";
text_size   = 9;     // [5:0.5:16]
font        = "Liberation Sans:style=Bold";
plate_pad   = 4;     // [2:0.5:8]
plate_thick = 2.4;   // [1.6:0.2:4]
text_height = 1.4;   // [0.6:0.2:3]
hole_r      = 2.8;   // [2:0.2:4]

len_est = len(name) * text_size * 0.78;
w = len_est + 2 * plate_pad + 2 * hole_r + 4;
h = text_size + 2 * plate_pad;

difference() {
    hull() {
        translate([h/2, h/2, 0]) cylinder(h = plate_thick, r = h/2, $fn = 64);
        translate([w - h/2, h/2, 0]) cylinder(h = plate_thick, r = h/2, $fn = 64);
    }
    translate([h/2, h/2, -1]) cylinder(h = plate_thick + 2, r = hole_r, $fn = 48);
}
translate([h/2 + hole_r + 3, h/2, plate_thick])
    linear_extrude(height = text_height)
        text(name, size = text_size, font = font, valign = "center");
