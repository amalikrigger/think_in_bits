// Phone Stand. One part, prints flat with no supports.
// Drag the sliders in Window > Customizer, F6 to render, File > Export > STL.

angle       = 65;   // [50:1:80]  lean of the phone, degrees from the table
width       = 60;   // [40:5:80]
thick       = 5;    // [3:0.5:8]
lip         = 10;   // [6:1:16]   height of the ledge in front of the phone
phone_depth = 12;   // [8:1:20]   phone plus case
back_len    = 55;   // [35:5:90]  how far the base reaches behind (stops it tipping)
rest_len    = 85;   // [50:5:120]

intersection() {
    union() {
        // base: reaches behind the corner so the stand does not tip back
        translate([-back_len, 0, 0]) cube([back_len + phone_depth + 2 * thick + 4, width, thick]);
        // back rest: rises up and back from the corner at x = 0
        rotate([0, -(180 - angle), 0]) cube([rest_len, width, thick]);
        // front lip: stops the phone sliding forward
        translate([phone_depth + 2, 0, 0]) cube([thick, width, lip + thick]);
    }
    translate([-500, -1, 0]) cube([1000, width + 2, 500]);   // trim anything below the table
}
