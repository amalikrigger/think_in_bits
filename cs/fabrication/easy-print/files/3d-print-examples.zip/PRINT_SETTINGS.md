# Formlabs demo prints: Clear V4 and Tough 2000

Example prints for the Easy 3D Print lesson, thinkinbits.site. Made 2026-11-10. Every file is watertight and sized for a Form 3 plate.
None has been printed yet. Resin volumes are the model only; supports add roughly 10 to 30 percent.

## Clear V4: things that look like glass

| File | Size (mm) | Resin | Why it suits Clear |
|---|---|---|---|
| `clear_gyroid_cube_30mm.stl` | 30 x 30 x 30 | about 9 mL | Light bends through the curved walls. The best "how did a printer do that" piece |
| `clear_tealight_shade.stl` | 52 x 52 x 50 | about 10 mL | Open at the bottom; slips over a battery tealight (about 38 mm across). The twist throws light patterns |
| `clear_lattice_ball_34mm.stl` | 35 x 35 x 35 | about 4.5 mL | Geodesic struts. Hold it up to the window |
| `clear_sea_glass_crystal.stl` | 23 x 26 x 32 | about 9 mL | Faceted gem. Sand and spray it and it looks like sea glass |

Battery tealights only in the shade. Never a real candle: cured resin burns.

## Tough 2000: things that have to work

| File | Size (mm) | Resin | Why it suits Tough 2000 |
|---|---|---|---|
| `tough_screw.stl` + `tough_nut.stl` | 22 x 25 x 31, and 9 tall | about 8.5 mL together | A real thread (5 mm pitch, 0.45 mm clearance). Students screw the nut on and off |
| `tough_clip_carabiner.stl` | 24 x 48 x 5 | about 2 mL | The gate flexes in and snaps back. Standard resin would crack; Tough 2000 bends |
| `gear_base.stl`, `gear_big_18t.stl`, `gear_small_11t.stl` (main demo folder) | base 70 x 46 | about 17 mL for all three | Gears that turn. Tough 2000 does not chip at the teeth |

## Settings (checked on formlabs.com 2026-11-10)

| | Clear V4 / V4.1 | Tough 2000 V2 |
|---|---|---|
| Form Wash, IPA | 10 min | 15 min (V1/V1.1: 10 min + 10 min) |
| Form Cure (V1) | 15 min at 60 C recommended, 30 min at 60 C for a full cure | 60 min at 70 C |
| Orientation | Tilt so supports touch the bottom and back, never the faces people look through | Tilt 30 to 45 degrees; keep supports off the thread and off the clip gate |

## Clear V4: how to get it to actually look clear
1. Wash the full 10 minutes. Poor washing is the main cause of yellow parts.
2. Cure on the short setting. Extra UV yellows Clear, so 15 minutes beats 30 for show pieces.
3. Straight off the printer it looks frosted. For glass: wet-sand 400 up to 3000 grit and polish, or two thin coats of clear acrylic spray (outside, adult only).

Sources: Formlabs, Form Cure Time and Temperature Settings; Formlabs, Form Wash Time Settings;
Additive-X, Ultimate Guide to Formlabs Clear Resin.
